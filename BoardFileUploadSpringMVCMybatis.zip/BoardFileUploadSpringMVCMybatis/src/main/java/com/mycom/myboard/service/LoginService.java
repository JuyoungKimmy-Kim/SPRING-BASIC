package com.mycom.myboard.service;

import com.mycom.myboard.dto.UserDto;

public interface LoginService {
	UserDto login(UserDto dto);
}
